# BIM Flight Data Management System - Demo Proposal

Sistem pengumpulan dan pengolahan data operasional penerbangan Bandar Udara Internasional Minangkabau.

## Struktur Folder

```
bim-flight-demo/
├── credentials/
│   └── credentials.json          ← Taruh file credentials di sini
├── data/
│   └── februari/                 ← Taruh file Excel harian di sini
├── notebooks/
│   └── demo_upload.ipynb
├── src/
│   ├── config.py
│   └── uploader.py
├── logs/
├── requirements.txt
└── README.md
```

## Cara Menggunakan

1. Install library:
   ```bash
   pip install -r requirements.txt
   ```

2. Letakkan file `credentials.json` di folder `credentials/`

3. Share Google Sheet ke email Service Account dengan akses **Editor**

4. Jalankan demo di notebook atau script.

## Google Sheet Structure

- **RAW_ARRIVAL** : Data kedatangan mentah
- **RAW_DEPARTURE** : Data keberangkatan mentah
- **LOG_UPLOAD** : Riwayat upload
