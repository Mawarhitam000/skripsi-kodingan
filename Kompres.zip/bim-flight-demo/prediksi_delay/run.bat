@echo off
echo ========================================
echo ✈️  Dashboard Prediksi Keterlambatan
echo ========================================
echo.
python app.py
pause