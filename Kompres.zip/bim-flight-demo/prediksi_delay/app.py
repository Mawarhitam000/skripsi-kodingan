# ============================================================
# DASHBOARD PREDIKSI KETERLAMBATAN PENERBANGAN
# ============================================================

from flask import Flask, render_template, request, jsonify
import joblib
import pickle
import pandas as pd
from datetime import datetime, timedelta
import os
import json

app = Flask(__name__)

# ============================================================
# CEK FILE MODEL
# ============================================================

print("\n" + "="*50)
print("✈️  DASHBOARD PREDIKSI KETERLAMBATAN")
print("="*50)

if not os.path.exists('model.pkl'):
    print("❌ ERROR: File model.pkl tidak ditemukan!")
    exit()

if not os.path.exists('encoders.pkl'):
    print("❌ ERROR: File encoders.pkl tidak ditemukan!")
    exit()

# ============================================================
# LOAD MODEL DAN ENCODERS
# ============================================================

print("📥 Loading model...")
model = joblib.load('model.pkl')
print("✅ Model loaded successfully!")

print("📥 Loading encoders...")
with open('encoders.pkl', 'rb') as f:
    encoders_data = pickle.load(f)
    encoders = encoders_data['encoders']
    target_mapping = encoders_data['target_mapping_combined']
    features = encoders_data['features']
print("✅ Encoders loaded successfully!")

# ============================================================
# LOAD DATA REAL DARI CSV
# ============================================================

print("📥 Loading data...")

if os.path.exists('data_final.csv'):
    df_real = pd.read_csv('data_final.csv')
    print(f"✅ Data loaded: {len(df_real)} rows")
else:
    print("⚠️ data_final.csv tidak ditemukan!")
    exit()

# Pastikan kolom Arrival_Date ada
if 'Arrival_Date' not in df_real.columns:
    for col in df_real.columns:
        if 'date' in col.lower() or 'Date' in col:
            df_real['Arrival_Date'] = pd.to_datetime(df_real[col], errors='coerce')
            break
    if 'Arrival_Date' not in df_real.columns:
        df_real['Arrival_Date'] = pd.date_range(end=datetime.now(), periods=len(df_real), freq='D')

df_real['Arrival_Date'] = pd.to_datetime(df_real['Arrival_Date'])

if 'Delay_Category_Encoded' not in df_real.columns:
    df_real['Delay_Category_Encoded'] = 0

if 'Departure_Hour' not in df_real.columns:
    df_real['Departure_Hour'] = 8

if 'Airline' not in df_real.columns:
    df_real['Airline'] = 'QG'

# ============================================================
# HITUNG STATISTIK DARI SEMUA DATA
# ============================================================

# Gunakan SEMUA data
all_data = df_real

total_flights_real = int(len(all_data))
total_otp_real = int(len(all_data[all_data['Delay_Category_Encoded'] == 0]))
total_delay_real = total_flights_real - total_otp_real
delay_rate_real = round(total_delay_real / total_flights_real * 100, 1) if total_flights_real > 0 else 0

print(f"\n📊 TOTAL SELURUH DATA: {total_flights_real} penerbangan")
print(f"📊 OTP: {total_otp_real}")
print(f"📊 Delay: {total_delay_real}")
print(f"📊 Rate Delay: {delay_rate_real}%")

print("\n" + "="*50)
print("📍 Server running at: http://127.0.0.1:5000")
print("="*50 + "\n")

# ============================================================
# FUNGSI UNTUK DATA REAL (SEMUA DATA)
# ============================================================

def get_real_daily_data():
    """Data per hari dari SEMUA data"""
    days_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    day_names_id = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu']
    
    result = []
    for i, day in enumerate(days_order):
        day_data = all_data[all_data['Arrival_Date'].dt.day_name() == day]
        total = int(len(day_data))
        otp = int(len(day_data[day_data['Delay_Category_Encoded'] == 0]))
        delay = total - otp
        result.append({
            'day': day_names_id[i],
            'total': total,
            'otp': otp,
            'delay': delay,
            'delay_rate': round(delay / total * 100, 1) if total > 0 else 0
        })
    
    return result

def get_real_hourly_data():
    """Data per jam dari SEMUA data"""
    result = []
    for hour in range(6, 22):
        hour_data = all_data[all_data['Departure_Hour'] == hour]
        total = int(len(hour_data))
        delay = int(len(hour_data[hour_data['Delay_Category_Encoded'] != 0]))
        result.append({
            'hour': f'{hour:02d}:00',
            'flights': total,
            'delay_rate': round(delay / total * 100, 1) if total > 0 else 0
        })
    
    return result

def get_real_airline_data():
    """Data per maskapai dari SEMUA data"""
    airlines = all_data['Airline'].unique()
    result = []
    for airline in airlines:
        data_airline = all_data[all_data['Airline'] == airline]
        total = int(len(data_airline))
        otp = int(len(data_airline[data_airline['Delay_Category_Encoded'] == 0]))
        delay = total - otp
        if total > 0:
            result.append({
                'airline': str(airline),
                'total': total,
                'otp': otp,
                'delay': delay,
                'otp_rate': round(otp / total * 100, 1),
                'delay_rate': round(delay / total * 100, 1)
            })
    
    return sorted(result, key=lambda x: x['total'], reverse=True)[:10]

# ============================================================
# PREPROCESSING
# ============================================================

def preprocess_input(data):
    df = pd.DataFrame([data])
    
    for col, encoder in encoders.items():
        if col in df.columns:
            encoded_col = col + '_Encoded'
            try:
                df[encoded_col] = encoder.transform(df[col].astype(str))
            except:
                df[encoded_col] = 0
    
    for col in ['Peak_Hour', 'Is_Weekend']:
        if col in df.columns:
            df[col] = df[col].astype(int)
    
    for feature in features:
        if feature not in df.columns:
            df[feature] = 0
    
    return df[features]

# ============================================================
# ROUTES
# ============================================================

@app.route('/')
def index():
    daily_data = get_real_daily_data()
    hourly_data = get_real_hourly_data()
    airline_data = get_real_airline_data()
    
    total_flights = sum(d['total'] for d in daily_data)
    total_otp = sum(d['otp'] for d in daily_data)
    total_delay = sum(d['delay'] for d in daily_data)
    days_with_data = [d for d in daily_data if d['total'] > 0]
    avg_delay_rate = round(sum(d['delay_rate'] for d in days_with_data) / len(days_with_data), 1) if days_with_data else 0
    
    return render_template('index.html',
        daily_data=daily_data,
        hourly_data=hourly_data,
        airline_data=airline_data,
        total_flights=total_flights,
        total_otp=total_otp,
        total_delay=total_delay,
        avg_delay_rate=avg_delay_rate
    )

@app.route('/predict')
def predict_page():
    return render_template('predict.html')

@app.route('/api/predict', methods=['POST'])
def predict():
    try:
        data = request.json
        
        # Validasi input
        errors = []
        if not data.get('flight_number'):
            errors.append("Flight Number harus diisi")
        if not data.get('airline'):
            errors.append("Airline harus dipilih")
        if not data.get('origin'):
            errors.append("Origin harus dipilih")
        if not data.get('destination'):
            errors.append("Destination harus dipilih")
        
        if errors:
            return jsonify({'success': False, 'error': ' | '.join(errors)}), 400
        
        X = preprocess_input(data)
        
        pred = model.predict(X)[0]
        proba = model.predict_proba(X)[0]
        
        pred_label = target_mapping.get(pred, f'K{pred}')
        
        delay_map = {
            'OTP': '0-29 menit',
            'K1': '30-59 menit',
            'Minor_Delay': '120-239 menit',
            'K5': '≥ 240 menit'
        }
        
        rekomendasi = {
            'OTP': '✅ Penerbangan tepat waktu. Lanjutkan normal.',
            'K1': '⚠️ Risiko delay rendah. Percepat ground handling.',
            'Minor_Delay': '🔴 Risiko delay tinggi! Prioritaskan penanganan.',
            'K5': '🔴 Risiko delay sangat tinggi! Koordinasi dengan maskapai.'
        }
        
        class_indices = {}
        for i, (idx, label) in enumerate(target_mapping.items()):
            class_indices[label] = i
        
        prob_dict = {}
        for label in ['OTP', 'K1', 'Minor_Delay', 'K5']:
            if label in class_indices:
                idx = class_indices[label]
                prob_dict[label] = round(float(proba[idx] * 100), 1)
            else:
                prob_dict[label] = 0.0
        
        return jsonify({
            'success': True,
            'flight': data.get('flight_number', 'Unknown'),
            'airline': data.get('airline', 'Unknown'),
            'destination': data.get('destination', 'Unknown'),
            'std': data.get('std', '08:00'),
            'prediction': pred_label,
            'estimated_delay': delay_map.get(pred_label, 'Tidak diketahui'),
            'recommendation': rekomendasi.get(pred_label, ''),
            'probabilities': prob_dict,
            'timestamp': datetime.now().strftime('%H:%M:%S')
        })
    
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)