"""
Demo Upload Data Mentah ke Google Sheets
Untuk keperluan Seminar Proposal Skripsi
"""

import sys
import os

# Tambahkan path src ke sys.path
SRC_PATH = os.path.join(os.path.dirname(__file__), 'src')
if SRC_PATH not in sys.path:
    sys.path.insert(0, SRC_PATH)

# Import dari src
from uploader import FlightDataUploader
from config import CREDENTIALS_PATH, GOOGLE_SHEET_KEY, DATA_DIR

def main():
    print("="*60)
    print("BIM FLIGHT SYSTEM - DEMO UPLOAD DATA MENTAH")
    print("="*60)
    
    # ==========================
    # Cek koneksi ke Google Sheets
    # ==========================
    
    print(f"\n🔍 Mencari credentials.json di: {CREDENTIALS_PATH}")
    if not os.path.exists(CREDENTIALS_PATH):
        print(f"❌ File credentials.json tidak ditemukan!")
        print("\nPastikan:")
        print("1. File credentials.json ada di folder credentials/")
        print("2. Nama file tepat 'credentials.json'")
        return
    print("✅ File credentials.json ditemukan")
    
    # Inisialisasi uploader
    try:
        uploader = FlightDataUploader(CREDENTIALS_PATH, GOOGLE_SHEET_KEY)
        print("✅ Berhasil terhubung ke Google Sheets")
    except Exception as e:
        print(f"❌ Gagal terhubung ke Google Sheets: {e}")
        print("\nPastikan:")
        print("1. File credentials.json valid")
        print("2. Google Sheet sudah di-share ke Service Account")
        return
    
    # ==========================
    # Tampilkan file Excel yang tersedia
    # ==========================
    print("\n📁 File Excel yang tersedia di data/februari/:")
    data_feb_dir = os.path.join(DATA_DIR, "februari")
    excel_files = []
    if os.path.exists(data_feb_dir):
        excel_files = [f for f in os.listdir(data_feb_dir) if f.endswith('.xlsx')]
        excel_files.sort()  # Urutkan berdasarkan nama
        if excel_files:
            for i, f in enumerate(excel_files, 1):
                print(f"   {i}. {f}")
        else:
            print("   (Tidak ada file Excel)")
    else:
        print(f"   Folder tidak ditemukan: {data_feb_dir}")
    
    # ==========================
    # Input file Excel (lebih user-friendly)
    # ==========================
    print("\n" + "="*60)
    print("MASUKAN FILE EXCEL")
    print("="*60)
    
    # Tanya user mau pilih dari daftar atau input manual
    if excel_files:
        print("\nPilih opsi:")
        print("1. Pilih dari daftar (masukkan nomor)")
        print("2. Input path manual")
        choice = input("\nPilihan (1/2): ").strip()
        
        if choice == "1":
            # Pilih dari daftar
            while True:
                try:
                    num = int(input(f"Masukkan nomor file (1-{len(excel_files)}): ").strip())
                    if 1 <= num <= len(excel_files):
                        selected_file = excel_files[num-1]
                        file_path = os.path.join(data_feb_dir, selected_file)
                        print(f"\n✅ Dipilih: {selected_file}")
                        break
                    else:
                        print(f"❌ Masukkan nomor antara 1 dan {len(excel_files)}")
                except ValueError:
                    print("❌ Masukkan angka yang valid")
        else:
            # Input manual dengan auto-complete path
            manual_input = input("\nMasukkan path file Excel: ").strip().strip('"')
            
            # Coba beberapa kemungkinan path
            possible_paths = [
                manual_input,  # Seperti yang dimasukkan user
                os.path.join(data_feb_dir, manual_input),  # Jika hanya nama file
                os.path.join(os.path.dirname(__file__), manual_input),  # Relative dari root
                os.path.join(DATA_DIR, manual_input),  # Di folder data
            ]
            
            file_path = None
            for path in possible_paths:
                if os.path.exists(path):
                    file_path = path
                    break
            
            if file_path is None:
                print(f"\n❌ File tidak ditemukan dalam lokasi mana pun!")
                print(f"   Mencari: {manual_input}")
                print("\nPastikan file ada di folder data/februari/")
                return
    else:
        # Tidak ada file di daftar, input manual
        manual_input = input("\nMasukkan path lengkap file Excel: ").strip().strip('"')
        file_path = manual_input
        if not os.path.isabs(file_path):
            file_path = os.path.join(os.path.dirname(__file__), file_path)
        
        if not os.path.exists(file_path):
            print(f"\n❌ File tidak ditemukan: {file_path}")
            return
    
    # Verifikasi file
    if not os.path.exists(file_path):
        print(f"\n❌ File tidak ditemukan:")
        print(f"   {file_path}")
        return
    
    print(f"\n✅ File ditemukan: {os.path.basename(file_path)}")
    
    # ==========================
    # Input tanggal data
    # ==========================
    # Ambil tanggal dari nama file jika memungkinkan
    default_date = None
    file_name = os.path.basename(file_path)
    import re
    date_match = re.search(r'(\d{2})-(\d{2})-(\d{4})', file_name)
    if date_match:
        day, month, year = date_match.groups()
        default_date = f"{year}-{month}-{day}"
    
    if default_date:
        print(f"\n📅 Tanggal terdeteksi dari nama file: {default_date}")
        data_date = input(f"Masukkan tanggal data (YYYY-MM-DD) [Enter untuk {default_date}]: ").strip()
        if not data_date:
            data_date = default_date
    else:
        data_date = input("\nMasukkan tanggal data (format YYYY-MM-DD): ").strip()
    
    # Validasi format tanggal
    try:
        from datetime import datetime
        datetime.strptime(data_date, "%Y-%m-%d")
    except ValueError:
        print("❌ Format tanggal salah! Gunakan format YYYY-MM-DD")
        return
    
    # ==========================
    # Proses Upload
    # ==========================
    print("\n" + "="*60)
    print("PROSES UPLOAD DIMULAI")
    print("="*60)
    
    try:
        total_arr, total_dep = uploader.upload_file(file_path, data_date)
        
        print("\n" + "="*60)
        print("🎉 UPLOAD BERHASIL!")
        print(f"   Total Arrival   : {total_arr} baris")
        print(f"   Total Departure : {total_dep} baris")
        print("="*60)
        
    except Exception as e:
        print(f"\n❌ Terjadi error saat upload:")
        print(f"   {e}")
        print("\nDetail error:")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()